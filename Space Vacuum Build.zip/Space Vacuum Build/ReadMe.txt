How to play

Find invisible creatures and vacuum them up

Menus:

Mouse - Hover over selection
Left click - Confirm selection
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
W/Up arrow - Move up 
S/Down arrow - Move down
Spacebar - Confirm selection

Gameplay: 

W A S D - Move player
Shift - Sprint
Spacebar - Jump
Mouse - Move camera
Right click - ready vacuum
Left click - fire vacuum

